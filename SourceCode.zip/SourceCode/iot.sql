/*
 Navicat Premium Data Transfer

 Source Server         : User TA 172.20.10.2
 Source Server Type    : MySQL
 Source Server Version : 100411
 Source Host           : 192.168.100.27:3306
 Source Schema         : taiot

 Target Server Type    : MySQL
 Target Server Version : 100411
 File Encoding         : 65001

 Date: 23/06/2020 13:44:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for smc_absen
-- ----------------------------
DROP TABLE IF EXISTS `smc_absen`;
CREATE TABLE `smc_absen`  (
  `ACS_ID` int(11) NULL DEFAULT NULL,
  `PGN_ID` int(11) NULL DEFAULT NULL,
  `ABS_IN` datetime(0) NOT NULL DEFAULT current_timestamp(0),
  `IS_DEL` int(11) NOT NULL DEFAULT 0,
  INDEX `PGN_ID`(`PGN_ID`) USING BTREE,
  INDEX `fk_absen_acs_to_acs`(`ACS_ID`) USING BTREE,
  CONSTRAINT `fk_absen_acs_to_acs` FOREIGN KEY (`ACS_ID`) REFERENCES `smc_access` (`ACS_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_absen_pgn_to_pgn` FOREIGN KEY (`PGN_ID`) REFERENCES `smc_pengguna` (`PGN_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for smc_access
-- ----------------------------
DROP TABLE IF EXISTS `smc_access`;
CREATE TABLE `smc_access`  (
  `ACS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PGN_ID` int(11) NULL DEFAULT NULL,
  `ACS_TIME_IN` datetime(0) NULL DEFAULT current_timestamp(0),
  `ACS_TIME_OUT` datetime(0) NOT NULL,
  `JDL_ID` int(11) NULL DEFAULT NULL,
  `ACS_KLS` int(11) NULL DEFAULT NULL,
  `IS_DEL` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ACS_ID`) USING BTREE,
  INDEX `fk_access_pgn_to_pgn`(`PGN_ID`) USING BTREE,
  INDEX `fk_access_jdl_to_jdl`(`JDL_ID`) USING BTREE,
  CONSTRAINT `fk_access_jdl_to_jdl` FOREIGN KEY (`JDL_ID`) REFERENCES `smc_jadwal` (`JDL_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_access_pgn_to_pgn` FOREIGN KEY (`PGN_ID`) REFERENCES `smc_pengguna` (`PGN_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 183 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for smc_datakelas
-- ----------------------------
DROP TABLE IF EXISTS `smc_datakelas`;
CREATE TABLE `smc_datakelas`  (
  `JDL_ID` int(11) NULL DEFAULT NULL,
  `PGN_ID` int(11) NULL DEFAULT NULL,
  `DK_MASUK` int(11) NOT NULL,
  `DK_ALFA` int(11) NOT NULL,
  INDEX `JDL_ID`(`JDL_ID`) USING BTREE,
  INDEX `PGN_ID`(`PGN_ID`) USING BTREE,
  CONSTRAINT `smc_datakelas_ibfk_1` FOREIGN KEY (`JDL_ID`) REFERENCES `smc_jadwal` (`JDL_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `smc_datakelas_ibfk_2` FOREIGN KEY (`PGN_ID`) REFERENCES `smc_pengguna` (`PGN_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for smc_jadwal
-- ----------------------------
DROP TABLE IF EXISTS `smc_jadwal`;
CREATE TABLE `smc_jadwal`  (
  `JDL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `JDL_MATKUL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `JDL_MULAI` time(0) NULL DEFAULT NULL,
  `JDL_SELESAI` time(0) NULL DEFAULT NULL,
  `JDL_HARI` enum('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'Senin',
  `JDL_DOSEN` int(11) NULL DEFAULT NULL,
  `JDL_MGG_KE` int(11) NOT NULL,
  `ACS_KLS` int(11) NULL DEFAULT NULL,
  `ACS_KLS_STATUS` int(11) NOT NULL,
  PRIMARY KEY (`JDL_ID`) USING BTREE,
  INDEX `fk_dosen_jadwal_to_pgn`(`JDL_DOSEN`) USING BTREE,
  CONSTRAINT `fk_dosen_jadwal_to_pgn` FOREIGN KEY (`JDL_DOSEN`) REFERENCES `smc_pengguna` (`PGN_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for smc_pengguna
-- ----------------------------
DROP TABLE IF EXISTS `smc_pengguna`;
CREATE TABLE `smc_pengguna`  (
  `PGN_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PGN_CARD_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `PGN_NAMA` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `PGN_STATUS` enum('Dosen','Mahasiswa') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `PGN_NOMOR_INDUK` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`PGN_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
